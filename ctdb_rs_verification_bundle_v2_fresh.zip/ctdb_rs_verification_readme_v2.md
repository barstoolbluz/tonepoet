# CTDB RS verification patch v2

Prepared on 2026-05-02.

## Artifacts

- `0001-ctdb-rs-verification-v2.patch` — replacement patch for `src/tui/ctdb.rs`.
- `CTDB_RS_VERIFICATION_README_v2.md` — this file.

## Apply

From the repository root:

```bash
git apply /path/to/0001-ctdb-rs-verification-v2.patch
cargo fmt
cargo test ctdb
cargo test ctdb_rs
cargo check
```

If `cargo test ctdb` is not a valid selector in the repo, run the nearest CTDB/TUI test target plus `cargo check`.

## What changed versus the first patch

The first patch was too conservative: it parsed `syndrome` but did not use it, and it defaulted the RS offset search to zero. That did not fully match CUETools behavior.

This v2 patch changes the verification flow to:

1. Query CTDB as before.
2. Decode the album/audio image.
3. Build the CTDB RS image as `[ctdb_rs::STRIDE zeros] + audio + [ctdb_rs::STRIDE zeros]`.
4. Parse `syndrome`, legacy inline `parity`, and `hasparity` from every CTDB entry.
5. Try entries highest-confidence-first.
6. Run a syndrome-first verifier over a CUETools-style one-stride offset window.
7. Use the downloaded full-parity verifier only as a fallback, with a narrow offset window so the current codec does not recompute full disc parity thousands of times.
8. Continue computing per-track CRC32 for diagnostics.
9. Mark tracks as:
   - `Verified` when CTDB CRC32 matches the selected entry.
   - `VerifiedRs` when RS verification passes but CTDB CRC32 differs.
   - `Mismatch` when RS verification did not pass and CRC32 differs.

The repair flow is not otherwise changed. Because `VerifiedRs` is not `Mismatch`, `:ctdb-repair` will not offer repair for a disc that is already RS-verified.

## Source behavior mirrored

CUETools.NET parses `syndrome`, `parity`, `hasparity`, and `trackcrcs` on response entries. Its `DBEntry` converts XML `stride` from stereo sample pairs to 16-bit words via `ctdbRespEntry.stride * 2`.

CUETools.NET also turns either compact `syndrome` or legacy inline `parity` into a one-row syndrome. Verification calls `FindOffset(entry.syndrome, entry.crc, ...)` first; full parity is fetched only when the entry differs but can potentially be repaired.

This patch mirrors that model at the TUI layer by adding a syndrome-first path and leaving the full-parity verifier as a fallback.

## Validation performed here

- Re-extracted the original `src/tui/ctdb.rs` from the uploaded bundle.
- Applied the previous patch to a temp tree and inspected it.
- Found two gaps: no syndrome-first check and zero default offset search.
- Regenerated a replacement patch against the original file from the bundle.
- Applied the new patch back onto a fresh copy of the original file and confirmed the result matched the generated file byte-for-byte.

I could not run `cargo check` because this environment has only the source snippets from the bundle, not the full crate.

## Review notes for the repo pass

1. Run `cargo fmt` first; this patch is generated without local `rustfmt` available.
2. Run `cargo check` and update any exhaustive UI rendering matches for the new `CtdbTrackStatus::VerifiedRs` variant.
3. Add a fixture test using the lookup XML for `0:24159:127166:278762:309864` and the 896-confidence entry.
4. Compare the detected `word_offset / 2` against CUETools output on the Allman Brothers test disc.
5. If the local `ctdb_rs` parity row orientation differs from CUETools' `Parity2Syndrome`, flip the sign in `parity_matrix_row_to_syndrome_row` from `-word_offset` to `word_offset`. The current patch follows CUETools' `y1 = (y - offset + stride2) % stride2` formula.
