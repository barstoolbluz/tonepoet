# CTDB repair source-translation patch

Generated on 2026-05-03 for the round-2 CTDB repair request.

This package replaces the current CTDB repair path that treats `hasparity` as raw parity. CUETools.NET stores and fetches `hasparity` as a full syndrome matrix, so the downloaded blob must be decoded with `Bytes2Syndrome(stride_words, npar, blob)` and XORed directly against `GetSyndrome(npar, -1, -actualOffset)`.

## Files

- `ctdb_cuetools_repair.rs` - source-grounded Rust block for `src/tui/ctdb.rs`.
- `0001_ctdb_repair_full_include.patch` - one-file include-style patch that adds `src/tui/ctdb_cuetools_repair.rs`, includes it from `ctdb.rs`, and changes the two current repair closures to call the new minimal adapter.
- `src_tui_ctdb_repair_minimal_callsite.patch` - small call-site patch that keeps the current public `repair_album` / `repair_single_image` signatures and constructs a repair entry from existing parameters.
- `src_tui_ctdb_repair_preferred_api.patch` - preferred follow-up API shape that passes a real `CtdbEntry` into repair, allowing the row-0 `hasparity`/`syndrome=` consistency check to mirror CUETools more closely.
- `repair_numeric_fixture.json` - fixture metadata and expected intermediate values.

## Integration order

1. For a direct patch workflow, apply `0001_ctdb_repair_full_include.patch`. It keeps the new source in `src/tui/ctdb_cuetools_repair.rs` and includes it into `ctdb.rs`.
2. For a manual paste workflow, insert the contents of `ctdb_cuetools_repair.rs` into `src/tui/ctdb.rs` after the existing verify-side helper/test block and before the parity download / repair orchestrator section, then apply `src_tui_ctdb_repair_minimal_callsite.patch`.
3. Prefer `src_tui_ctdb_repair_preferred_api.patch` when you are ready to pass the selected `CtdbEntry` through the UI/repair flow.
4. Run:

```bash
cargo test cuetools_translation_fixtures
cargo test cuetools_repair_translation_fixtures
cargo test ctdb_rs
```

5. Re-run the Allman Brothers SHM Disc 2 empirical check. Expected behavior for entry `113068`, `actualOffset = +5408`: if all full-matrix columns match, `corrected_samples = 0`; if RS-equivalent bytes need canonicalization, corrections must be followed by canonical per-track CRCs `40c5dc10 65dfcc8a 1ef7b539 d21a8789`.

I could not compile this in your local checkout because the repository itself was not uploaded. The code targets the current public `barstoolbluz/tonepoet` `src/tui/ctdb.rs` shape that already contains the verify translation.

## Source answers

### 1. Full-matrix `GetSyndrome(npar, -1, offset)`

CUETools does not use a separate algorithm for the full matrix. In `AccurateRipVerify.GetSyndrome`, `strides == -1` is replaced with the full `stride`, then the same `part2` loop and both first/last boundary corrections are applied per output column.

Short source anchors:

```csharp
if (strides == -1) strides = stride;
```

```csharp
for (int part2 = 0; part2 < strides; part2++)
```

The Rust `cuetools_get_syndrome_matrix` is the existing row helper generalized from `part2 = 0` to `part2 in 0..stride`, with the same boundary correction predicates and per-symbol `mulExp` / `divExp` operations.

### 2. Blob row alignment vs offset

The downloaded `hasparity` bytes are decoded directly as a syndrome matrix:

```csharp
syn = ParityToSyndrome.Bytes2Syndrome(entry.stride, npar, contents);
```

`VerifyParity` then computes the local matrix with:

```csharp
var syn1 = ar.GetSyndrome(npar, -1, -actualOffset);
```

Then it indexes both matrices with the same `part2` row and XORs symbol-for-symbol. There is no post-decode row rotation of the downloaded matrix.

### 3. Per-column repair loop

CUETools decodes independently per column. The effective maximum is `npar / 2` per column, not a global error-count bound across the whole disc. If any non-zero column fails BM/Chien or exceeds the per-column threshold, repair is marked not recoverable and returns immediately.

Short source anchors:

```csharp
int efLen = npar / 2;
```

```csharp
if (errcount <= 0 || errcount > efLen || !rs.chienSearch(...))
```

The Rust patch follows that: any column with `errors_found == 0`, `errors_found > npar / 2`, invalid Chien roots, invalid Forney magnitudes, or non-zero residual returns `RepairError::Uncorrectable`.

### 4. Audio sample-index mapping

The prompt's simplified mapping `STRIDE + row * STRIDE + column` is correct only when `actualOffset == 0`. CUETools source includes the offset term while converting a located `(row, column)` into the correction stream index:

```csharp
int pos = ... * stride + part2;
```

```csharp
int erroffi = stride + pos + pregap * 2 - actualOffset * 2;
```

and the writer applies:

```csharp
data[pos] ^= forneysorted[nexterroff++];
```

The patch maps that onto tonepoet's padded disc image as:

```rust
STRIDE + row * STRIDE + column - 2 * actual_offset
```

At offset zero this is exactly the current codec mapping. At a non-zero `actualOffset`, this source finding intentionally overrides the no-offset simplification.

### 5. Repair invariants and failure semantics

CUETools does not rebuild the full syndrome matrix after applying samples in `VerifyParity`; it CRC-validates the candidate correction set before returning the fix object:

```csharp
crc ^= ar.CTDBCRC(-actualOffset);
```

If that CRC is non-zero, `canRecover` becomes false. Actual sample changes are applied later by `CDRepairFix.Write` while streaming the output. Since this patch does not have `AccurateRipVerify`'s CTDB CRC cache available in `src/tui/ctdb.rs`, it substitutes a stricter local invariant: after applying corrections, it recomputes `GetSyndrome(npar, -1, -actualOffset)` and requires full equality with the downloaded matrix. If that post-check fails, it reverts the changed samples and returns `InvalidInput`.

### 6. Numeric fixture

The fixture is intentionally small in row count but uses the real CTDB stride (`11760`) and GF(2^16) arithmetic.

Setup:

```text
npar = 4
full_rows = 5
protected_rows = 3
sample_offset = 0
lead-in and lead-out rows = zero
protected word pattern = ((idx * 257 + 0x1234) & 0xffff)
```

Injected errors:

```text
(row 0, column 10) ^= 0x0101
(row 1, column 11) ^= 0x7777
(row 2, column 10) ^= 0x0202
```

Expected non-zero deltas:

```text
column 10 delta = [0x0303, 0x0606, 0x1212, 0x4242]
BM sigma        = [0x0001, 0x0005, 0x0004]
Chien rows      = [0, 2]
Forney mags     = [0x0101, 0x0202]

column 11 delta = [0x7777, 0xeeee, 0xcdd7, 0x8ba5]
BM sigma        = [0x0001, 0x0002]
Chien rows      = [1]
Forney mags     = [0x7777]
```

The `#[test]` in `ctdb_cuetools_repair.rs` asserts `corrected_samples == 3`, `verified_after == true`, and full audio equality with the original synthetic image.

## Why the old path is wrong

The current `CtdbCodec::repair_with_word_offset` path decodes the provided bytes using the raw-parity layout and then calls `parity_to_syndrome_with_word_offset` on both computed and provided matrices. That is correct only for internally generated raw parity blobs. Real CTDB `hasparity` blobs are already syndrome matrices, so applying `Parity2Syndrome` to them creates a second transform that CUETools never performs.

## Minimal-vs-preferred call site

The minimal patch keeps current public repair signatures:

```rust
repair_album(paths, parity_url, npar, offset, expected_crcs, tx)
repair_single_image(info, parity_url, npar, offset, expected_crcs, tx)
```

It constructs a synthetic `CtdbEntry` containing `npar`, `stride`, `has_parity`, and `track_crcs`. That is enough to repair the blob correctly, but it cannot perform the exact CUETools row-0 XML `syndrome=` consistency check unless the caller also provides the entry's `syndrome` field.

The preferred patch changes repair signatures to accept `&CtdbEntry`. That mirrors the CUETools flow: selected entry -> fetch hasparity -> check row 0 against entry.syndrome -> repair.
