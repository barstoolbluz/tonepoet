# CTDB syndrome fast-path translation from CUETools.NET source

Generated on 2026-05-03 from the current `gchudov/cuetools.net` GitHub source. This package is source-grounded: each translated Rust block in `ctdb_cuetools_fastpath.rs` carries a `// matches ...:line-line` marker.

## Files in this package

- `ctdb_cuetools_fastpath.rs` — Rust replacement code for the previous v3 CTDB syndrome fast path and helpers.
- `src_tui_ctdb_replacement.patch` — patch fragment containing the same replacement block for `src/tui/ctdb.rs`.
- `numeric_fixture.json` — small deterministic GF/Parity2Syndrome fixtures.
- `README.md` — this integration guide.

## Source files actually used

The repository layout differs from the paths in the brief in several important places.

| Role | Actual source path | Source range used | Short C# anchor |
|---|---:|---:|---|
| GF(2^16) arithmetic | `CUETools.Parity/Galois.cs` | file-level constants and tables | `0x1100b` |
| `AccurateRipVerify`, `GetSyndrome` | `CUETools.AccurateRip/AccurateRip.cs` | 2247-2252, 2782-2848, 2915-2933, 3607-3622 | `GetSyndrome(... offset = 0)` |
| parity/syndrome serialization and transform | `CUETools.Parity/Parity2Syndrome.cs` | 683-735, 770-823 | `Bytes2Syndrome`, `Parity2Syndrome` |
| repair geometry and verifier offset loop | `CUETools.AccurateRip/CDRepair.cs` | 1113-1129, 1252-1349 | `GetSyndrome(npar, 1, -offset)` |
| CTDB XML schema | `CUETools.CTDB.Types/CTDBResponseEntry.cs` | 303-346 | `syndrome`, `parity`, `hasparity` |
| DB XML normalization | `CUETools.CTDB/DBEntry.cs` | 441-445, 449 | `Bytes2Syndrome`, `Parity2Syndrome` |
| CTDB full-blob fetch/submit and verify caller | `CUETools.CTDB/CUEToolsDB.cs` | 2168-2280, 2492-2500, 2594-2674 | `verify.FindOffset(...)` |

## Main source-grounded conclusions

### 1. `syndrome=` is already in CUETools syndrome domain

The canonical XML attribute named `syndrome` is decoded by `DBEntry` with `Bytes2Syndrome(1, min(maxNpar, npar), ...)`. There is no `Parity2Syndrome` call for that attribute. The Rust patch therefore decodes it as a row of `ushort[1,npar]` and compares it directly to `GetSyndrome(npar, 1, -candidate_offset)`.

Your empirical observation that the canonical `syndrome=` bytes equal row 0 of the downloaded `hasparity` blob is consistent with source behavior: the downloadable blob is serialized with CUETools' syndrome layout (`Syndrome2Bytes(GetSyndrome(...))`), despite being historically named `parity` in several variables and URLs. Its byte layout matches your `bytes_to_parity` function, but its semantics are syndrome, not raw parity.

### 2. Legacy inline `parity=` is different

When `syndrome` is missing, `DBEntry` converts legacy inline `parity=` with `Parity2Syndrome(1, 1, 8, 8, ...)`. The patch mirrors that with `cuetools_legacy_inline_parity_to_syndrome_row()`.

### 3. `GetSyndrome` offset units and sign

`AccurateRipVerify.GetSyndrome(npar, columns, offset)` takes `offset` in CD stereo sample pairs, not i16 words. Internally it multiplies by 2 to convert to i16-word offsets.

`CDRepair.FindOffset` scans candidate offsets and calls `GetSyndrome(npar, 1, -candidate_offset)`. Therefore a candidate offset of `+6` is evaluated through `GetSyndrome(..., -6)`, which uses a word rotation of `+12` in the `Parity2Syndrome` call and then applies the boundary correction logic. The returned `RsVerifiedMatch.offset` in the patch is the same sign as CUETools' `actualOffset` output.

For STRIDE=11760, the CUETools loop is exactly:

- start: `1 - stride / 2` = `-5879`
- end: `< stride / 2` = last candidate `+5879`

The patch intersects that source range with your `offset_window`.

### 4. `ushort[,]` layout vs Rust `Vec<Vec<u16>>`

CUETools uses `ushort[stride, npar]`, indexed as `[row, parity_symbol]`. `Bytes2Syndrome(stride, npar, bytes)` reads little-endian words from serialized index `(row + parity_symbol * stride)` into `[row, parity_symbol]`.

The patch represents this as `Vec<Vec<u16>>` with `rows[row][parity_symbol]`. For canonical `syndrome=`, the shape is `[1][npar]`. For legacy inline `parity=`, the resulting converted shape is `[1][8]`. For full `hasparity`, the decoded shape is `[stride][npar]`, again already in syndrome domain.

### 5. `maxNpar=16` matters even for `npar=8`

CUETools keeps the AccurateRip verifier parity workspace at `maxNpar=16`. `GetSyndrome(npar, ...)` narrows only the output row length; it still calls `Parity2Syndrome(..., npar2=maxNpar, ...)`. The patch therefore computes `compute_parity_matrix_from_audio(..., 16)` exactly once and derives both 8-symbol and 16-symbol comparison rows from that source matrix. Computing an 8-symbol parity matrix for an `npar=8` entry is not source-equivalent.

## Applying the patch

1. Open `src/tui/ctdb.rs`.
2. Remove the previous v3 helpers:
   - `parity_row_to_syndrome_row`
   - `row_for_sample_offset`
   - `verify_entry_via_syndrome_fast_path`
   - the previous `verify_disc_via_rs` body
3. Paste `ctdb_cuetools_fastpath.rs` in their place.
4. Adjust only the adapter functions if your `CtdbEntry` fields differ:
   - `ctdb_entry_npar`
   - `ctdb_entry_confidence`
   - `ctdb_entry_syndrome_b64`
   - `ctdb_entry_inline_parity_b64`
5. If your project uses `base64` 0.21+ or 0.22+, add this import near the top of `src/tui/ctdb.rs`:

   ```rust
   use base64::Engine as _;
   ```

   If the project is on an older `base64` crate, replace the two `.decode(...)` calls with `base64::decode(...)`.

6. Run the included fixtures:

   ```bash
   cargo test parity2syndrome_single_row_fixture bytes2syndrome_layout_fixture
   ```

7. Run your Allman Brothers CTDB verification. The canonical confidence-896 row should be evaluated by comparing:

   ```text
   entry_row = Bytes2Syndrome(1, 16, base64(syndrome))[0]
   our_row   = GetSyndrome(16, 1, -candidate_offset)[0]
   delta     = xor(our_row, entry_row)
   ```

   The likely EAC offset-correction neighborhood to watch is candidate `+6` or `-6`, but the patch scans the full CUETools source range unless `offset_window` narrows it.

## Numeric fixtures

These are intentionally small and independent of CD audio. They test only the GF transform and serialization layout.

### Fixture A: Parity2Syndrome one-row transform

GF primitive polynomial: `0x1100B`; generator alpha: `2`; field max: `65535`.

Input:

```text
source_npar = 4
out_npar    = 4
parity_row  = [0x1234, 0xabcd, 0x0000, 0xbeef]
```

Expected syndrome row:

```text
[0x0716, 0x3907, 0xcf58, 0xcf08]
```

### Fixture B: Parity2Syndrome row selection with word offsets

Input matrix, indexed as `[row][symbol]`:

```text
row0 = [0x1111, 0x2222, 0x3333, 0x4444]
row1 = [0x0001, 0x0002, 0x0004, 0x0008]
row2 = [0x1234, 0xabcd, 0x0000, 0xbeef]
row3 = [0x0101, 0x0202, 0x0303, 0x0404]
row4 = [0xaaaa, 0xbbbb, 0xcccc, 0xdddd]
```

Using `Parity2Syndrome(stride=1, stride2=5, npar=4, npar2=4, offset=...)`:

```text
offset  0 words -> y1=0 -> [0x4444, 0xec24, 0x1f6e, 0xbca7]
offset +2 words -> y1=3 -> [0x0404, 0xee26, 0x91ed, 0xab79]
offset -2 words -> y1=2 -> [0x0716, 0x3907, 0xcf58, 0xcf08]
```

For `GetSyndrome(sample_offset)` at real CTDB stride 11760, before boundary correction:

```text
sample_offset -1 -> selected raw row 11758, part 11758
sample_offset  0 -> selected raw row 0,     part 0
sample_offset +1 -> selected raw row 2,     part 2
sample_offset +6 -> selected raw row 12,    part 12
sample_offset -6 -> selected raw row 11748, part 11748
```

Because `FindOffset` calls `GetSyndrome(..., -candidate_offset)`, candidate `+6` selects raw row `11748` before the final-boundary correction.

## Failure modes handled by this translation

- Avoids treating canonical `syndrome=` as raw parity.
- Avoids applying `Parity2Syndrome` twice to canonical `syndrome=`.
- Uses source `maxNpar=16` parity input even when output `npar` is 8.
- Implements the `GetSyndrome` sign convention: `FindOffset` candidate -> `GetSyndrome(..., -candidate)`.
- Implements the source offset scan bounds: `[-5879, +5879]` for STRIDE=11760.
- Implements `GetSyndrome` boundary corrections using lead-in and reversed lead-out side buffers.
- Mirrors the source BM/Chien acceptance rule: `err_count > 0 && err_count < npar/2` and Chien over `stridecount`.
- Preserves the exact-zero branch separately from BM/Chien.

## Known integration caveat

CUETools' exact-zero branch still sets `hasErrors` by comparing `CTDBCRC(-offset)` with the entry CRC. The patch returns an exact zero-syndrome match immediately because the brief's public surface does not expose a CTDBCRC-equivalent helper. If you already have that CRC calculation, wire it into the exact-zero branch before labeling a match as clean; otherwise treat `column0_errors == 0` as source-equivalent syndrome verification, not a complete clone of CUETools' status labeling.
