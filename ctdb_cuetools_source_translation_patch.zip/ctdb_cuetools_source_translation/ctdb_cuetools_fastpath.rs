// CUETools.NET CTDB syndrome fast-path translation for src/tui/ctdb.rs.
// Generated from the CUETools.NET source ranges listed in README.md.
//
// Integration intent:
//   - Replace the previous parity_row_to_syndrome_row(), row_for_sample_offset(),
//     verify_entry_via_syndrome_fast_path(), and verify_disc_via_rs() block.
//   - Keep your existing CtdbEntry, RsVerifiedMatch, and RsVerifySource types.
//   - Adjust only the small CtdbEntry adapter functions below if your field names differ.

use base64::Engine as _;

const CUETOOLS_MAX_NPAR: usize = 16;

#[derive(Clone, Debug)]
struct CuetoolsSyndromeContext {
    stride: usize,
    stridecount: usize,
    laststride: usize,
    leadin: Vec<u16>,
    leadout: Vec<u16>,
}

#[inline]
fn i16_as_u16_bits(sample: i16) -> u16 {
    sample as u16
}

/// Reconstructs the side buffers that CUETools AccurateRipVerify.GetSyndrome()
/// reads when an offset crosses the first/last RS column boundary.
///
/// matches CUETools.AccurateRip/CDRepair.cs:1113-1129
/// matches CUETools.AccurateRip/AccurateRip.cs:2915-2933
/// matches CUETools.AccurateRip/AccurateRip.cs:3607-3622
fn cuetools_build_syndrome_context(audio: &[i16]) -> Option<CuetoolsSyndromeContext> {
    let stride = crate::ctdb_rs::STRIDE;
    if audio.len() < stride * 2 {
        return None;
    }

    // In this project the image passed to the codec is:
    // [STRIDE i16 lead-in padding] + track data + [STRIDE i16 lead-out padding].
    let data_words = audio.len().checked_sub(stride * 2)?;
    let stridecount = data_words / stride;
    let laststride = stride + (data_words % stride);

    // CUETools allocates at least stride*2 words of lead-in context.
    let mut leadin = vec![0u16; stride * 2];
    for (dst, src) in leadin.iter_mut().zip(audio.iter()) {
        *dst = i16_as_u16_bits(*src);
    }

    // CUETools stores leadout in reverse order; index 0 is the final word seen.
    let mut leadout = vec![0u16; stride + laststride];
    for (dst_index, dst) in leadout.iter_mut().enumerate() {
        if let Some(src_index) = audio.len().checked_sub(1 + dst_index) {
            *dst = i16_as_u16_bits(audio[src_index]);
        }
    }

    Some(CuetoolsSyndromeContext {
        stride,
        stridecount,
        laststride,
        leadin,
        leadout,
    })
}

#[inline]
fn gf_mul_exp(gf: &crate::ctdb_rs::Galois16, value: u16, exp: usize) -> u16 {
    if value == 0 {
        0
    } else {
        gf.mul(value, gf.alpha_pow(exp % crate::ctdb_rs::galois::MAX))
    }
}

#[inline]
fn gf_div_exp(gf: &crate::ctdb_rs::Galois16, value: u16, exp: usize) -> u16 {
    if value == 0 {
        0
    } else {
        gf.div(value, gf.alpha_pow(exp % crate::ctdb_rs::galois::MAX))
    }
}

/// CUETools ParityToSyndrome.Bytes2Syndrome layout:
///   C# ushort[stride, npar], indexed as [row, parity_symbol].
///   Serialized word index is j + i * stride.
///
/// This is a layout conversion only. It does not mean a CTDB hasparity blob is
/// raw parity; CUETools serializes GetSyndrome() for the blob.
///
/// matches CUETools.Parity/Parity2Syndrome.cs:710-735
fn cuetools_bytes_to_syndrome_matrix(
    bytes: &[u8],
    stride: usize,
    npar: usize,
) -> Option<Vec<Vec<u16>>> {
    let required = stride.checked_mul(npar)?.checked_mul(2)?;
    if bytes.len() < required {
        return None;
    }

    let mut out = vec![vec![0u16; npar]; stride];
    for i in 0..npar {
        for j in 0..stride {
            let k = (j + i * stride) * 2;
            out[j][i] = u16::from_le_bytes([bytes[k], bytes[k + 1]]);
        }
    }
    Some(out)
}

/// Direct translation of ParityToSyndrome.Parity2Syndrome's inner transform for
/// one output row.
///
/// Important: CUETools.GetSyndrome(npar, ...) always transforms from the
/// maxNpar=16 parity workspace, even when out_npar is 8.
///
/// matches CUETools.Parity/Parity2Syndrome.cs:770-823
fn cuetools_parity_row_to_syndrome_row(
    gf: &crate::ctdb_rs::Galois16,
    parity_row: &[u16],
    out_npar: usize,
    source_npar: usize,
) -> Option<Vec<u16>> {
    if out_npar > source_npar || parity_row.len() < source_npar {
        return None;
    }

    let gf_max = crate::ctdb_rs::galois::MAX;
    let mut syn = vec![0u16; out_npar];

    for x1 in 0..source_npar {
        // matches CUETools.Parity/Parity2Syndrome.cs:808-810
        let lo = parity_row[x1];
        if lo == 0 {
            continue;
        }

        // C#: llo = plog[lo] + 0xffff; syn[x] ^= pexp[llo - (1 + x1) * x]
        // matches CUETools.Parity/Parity2Syndrome.cs:811-816
        let log_lo = gf.log(lo)?;
        for x in 0..out_npar {
            let decrement = ((1 + x1) * x) % gf_max;
            let exp = (log_lo + gf_max - decrement) % gf_max;
            syn[x] ^= gf.alpha_pow(exp);
        }
    }

    Some(syn)
}

/// Direct translation of AccurateRipVerify.GetSyndrome(..., strides: 1, offset)
/// for the single CTDB row used by CDRepairEncode.FindOffset.
///
/// `sample_offset` is CUETools GetSyndrome's `offset` parameter, in stereo
/// sample pairs. CDRepair calls this with `-candidate_offset`.
///
/// matches CUETools.AccurateRip/AccurateRip.cs:2782-2802
/// matches CUETools.AccurateRip/AccurateRip.cs:2805-2848
fn cuetools_get_syndrome_row(
    gf: &crate::ctdb_rs::Galois16,
    parity16: &[Vec<u16>],
    ctx: &CuetoolsSyndromeContext,
    out_npar: usize,
    sample_offset: i32,
) -> Option<Vec<u16>> {
    if out_npar > CUETOOLS_MAX_NPAR || parity16.len() < ctx.stride {
        return None;
    }

    let stride_i64 = ctx.stride as i64;
    let part2 = 0_i64;

    // C#: Parity2Syndrome(strides, stride, npar, maxNpar, parity, 0, -offset * 2)
    // For row part2=0, Parity2Syndrome selects y1=(part2 - (-offset*2)) mod stride.
    // matches CUETools.AccurateRip/AccurateRip.cs:2798-2802
    let parity2syndrome_word_offset = -2_i64 * sample_offset as i64;
    let y1 = (part2 - parity2syndrome_word_offset).rem_euclid(stride_i64) as usize;

    let mut syn = cuetools_parity_row_to_syndrome_row(
        gf,
        parity16.get(y1)?,
        out_npar,
        CUETOOLS_MAX_NPAR,
    )?;

    // C#: part = (part2 + offset * 2 + stride) % stride
    // matches CUETools.AccurateRip/AccurateRip.cs:2808
    let offset_words = 2_i64 * sample_offset as i64;
    let part = (part2 + offset_words).rem_euclid(stride_i64);

    // C# first-boundary correction.
    // matches CUETools.AccurateRip/AccurateRip.cs:2810-2827
    if part < offset_words {
        let part_usize = part as usize;
        for i in 0..out_npar {
            let mut syn_i = gf_mul_exp(gf, syn[i], i);
            syn_i ^= *ctx.leadout.get(ctx.laststride.checked_sub(part_usize + 1)?)?;

            let leadin_index = ctx.stride.checked_add(part_usize)?;
            let exp = (i * ctx.stridecount) % crate::ctdb_rs::galois::MAX;
            syn_i ^= gf_mul_exp(gf, *ctx.leadin.get(leadin_index)?, exp);
            syn[i] = syn_i;
        }
    }

    // C# last-boundary correction.
    // matches CUETools.AccurateRip/AccurateRip.cs:2829-2846
    if part >= stride_i64 + offset_words {
        let part_usize = part as usize;
        for i in 0..out_npar {
            let leadout_index = ctx
                .laststride
                .checked_add(ctx.stride)?
                .checked_sub(part_usize + 1)?;
            let exp = (i * ctx.stridecount) % crate::ctdb_rs::galois::MAX;
            let mut syn_i = syn[i]
                ^ *ctx.leadout.get(leadout_index)?
                ^ gf_mul_exp(gf, *ctx.leadin.get(part_usize)?, exp);
            syn_i = gf_div_exp(gf, syn_i, i);
            syn[i] = syn_i;
        }
    }

    Some(syn)
}

/// Legacy inline `parity=` entries are the old one-row NPAR=8 form.
/// DBEntry.cs converts them with Parity2Syndrome(1, 1, 8, 8, ...).
///
/// matches CUETools.CTDB/DBEntry.cs:441-445
/// matches CUETools.Parity/Parity2Syndrome.cs:770-823
fn cuetools_legacy_inline_parity_to_syndrome_row(
    gf: &crate::ctdb_rs::Galois16,
    bytes: &[u8],
) -> Option<Vec<u16>> {
    let npar = 8;
    if bytes.len() < npar * 2 {
        return None;
    }

    let mut parity_row = vec![0u16; npar];
    for i in 0..npar {
        let k = i * 2;
        parity_row[i] = u16::from_le_bytes([bytes[k], bytes[k + 1]]);
    }

    cuetools_parity_row_to_syndrome_row(gf, &parity_row, npar, npar)
}

// ---- CtdbEntry field adapters ------------------------------------------------
// Adjust these four helpers if your struct uses different names or types.

fn ctdb_entry_npar(entry: &CtdbEntry) -> usize {
    entry.npar as usize
}

fn ctdb_entry_confidence(entry: &CtdbEntry) -> u32 {
    entry.confidence as u32
}

fn ctdb_entry_syndrome_b64(entry: &CtdbEntry) -> Option<&str> {
    entry.syndrome.as_deref().filter(|s| !s.is_empty())
}

fn ctdb_entry_inline_parity_b64(entry: &CtdbEntry) -> Option<&str> {
    entry.parity.as_deref().filter(|s| !s.is_empty())
}

/// Canonical `syndrome=` is already a CUETools syndrome row. Do not run it
/// through Parity2Syndrome again.
///
/// matches CUETools.CTDB/DBEntry.cs:441-445
/// matches CUETools.Parity/Parity2Syndrome.cs:710-735
fn decode_entry_row_cuetools(
    gf: &crate::ctdb_rs::Galois16,
    entry: &CtdbEntry,
) -> Option<(Vec<u16>, usize, RsVerifySource)> {
    if let Some(syndrome_b64) = ctdb_entry_syndrome_b64(entry) {
        let npar = ctdb_entry_npar(entry).min(CUETOOLS_MAX_NPAR);
        if npar == 0 {
            return None;
        }

        let bytes = base64::engine::general_purpose::STANDARD
            .decode(syndrome_b64)
            .ok()?;
        let matrix = cuetools_bytes_to_syndrome_matrix(&bytes, 1, npar)?;
        return Some((matrix.into_iter().next()?, npar, RsVerifySource::Syndrome));
    }

    if let Some(parity_b64) = ctdb_entry_inline_parity_b64(entry) {
        // DBEntry.cs hard-codes legacy inline parity to NPAR=8, independent of
        // the XML npar field.
        let npar = 8;
        let bytes = base64::engine::general_purpose::STANDARD
            .decode(parity_b64)
            .ok()?;
        let row = cuetools_legacy_inline_parity_to_syndrome_row(gf, &bytes)?;
        return Some((row, npar, RsVerifySource::InlineParity));
    }

    None
}

/// Optional helper for full `hasparity` blobs.
/// CUETools serializes GetSyndrome(npar, -1, offset) with Syndrome2Bytes();
/// use this decoder before comparing full rows. Do not feed the blob through a
/// raw-parity transform unless you are deliberately handling a different legacy
/// source.
///
/// matches CUETools.CTDB/CUEToolsDB.cs:2168-2280
/// matches CUETools.CTDB/CUEToolsDB.cs:2492-2500
/// matches CUETools.Parity/Parity2Syndrome.cs:683-707
/// matches CUETools.Parity/Parity2Syndrome.cs:710-735
#[allow(dead_code)]
fn decode_full_hasparity_blob_as_syndrome_matrix(
    bytes: &[u8],
    stride: usize,
    npar: usize,
) -> Option<Vec<Vec<u16>>> {
    cuetools_bytes_to_syndrome_matrix(bytes, stride, npar)
}

/// Source-faithful single-entry FindOffset translation.
///
/// Candidate `offset` here is C# FindOffset's `actualOffset` output.
/// C# calls ar.GetSyndrome(npar, 1, -offset), so this function does the same.
///
/// matches CUETools.AccurateRip/CDRepair.cs:1252-1349
fn verify_entry_via_syndrome_fast_path(
    gf: &crate::ctdb_rs::Galois16,
    parity16: &[Vec<u16>],
    ctx: &CuetoolsSyndromeContext,
    entry: &CtdbEntry,
    offset_lo: i32,
    offset_hi: i32,
) -> Option<RsVerifiedMatch> {
    // C#: npar2 = syn2.GetLength(1); npar = Math.Min(maxNpar, npar2)
    // matches CUETools.AccurateRip/CDRepair.cs:1256-1261
    let (entry_row, npar, source) = decode_entry_row_cuetools(gf, entry)?;
    if entry_row.len() < npar {
        return None;
    }

    let mut best_offset = 0_i32;
    let mut best_offset_errors = npar / 2;

    // C#: for (int offset = 1 - stride / 2; offset < stride / 2; offset++)
    // The caller supplies the already-clipped range, normally -5879..=5879.
    // matches CUETools.AccurateRip/CDRepair.cs:1285
    for candidate_offset in offset_lo..=offset_hi {
        // C#: var syn1 = ar.GetSyndrome(npar, 1, -offset)
        // matches CUETools.AccurateRip/CDRepair.cs:1288
        let our_row = cuetools_get_syndrome_row(gf, parity16, ctx, npar, -candidate_offset)?;

        // C#: syndromes[i] = (ushort)(syn1[0, i] ^ syn2part[i])
        // matches CUETools.AccurateRip/CDRepair.cs:1290-1300
        let mut delta = vec![0u16; npar];
        for i in 0..npar {
            delta[i] = our_row[i] ^ entry_row[i];
        }

        // C# exact-zero branch. CUETools then uses CTDBCRC(-offset) only to set
        // hasErrors; this patch cannot reproduce that unless your caller exposes
        // AccurateRipVerify.CTDBCRC-equivalent CRC calculation.
        // matches CUETools.AccurateRip/CDRepair.cs:1293-1312
        if delta.iter().all(|&word| word == 0) {
            return Some(RsVerifiedMatch {
                entry: entry.clone(),
                offset: candidate_offset,
                confidence: ctdb_entry_confidence(entry),
                npar,
                source,
                column0_errors: 0,
            });
        }

        // C#: rs.modified_berlekamp_massey(...); if err_count > 0 && err_count < best...
        // matches CUETools.AccurateRip/CDRepair.cs:1316-1324
        let Some((sigma, errors_found)) = crate::ctdb_rs::berlekamp_massey(gf, &delta, npar) else {
            continue;
        };
        if errors_found > 0 && errors_found < best_offset_errors {
            // C#: chienSearch(..., stridecount, ...)
            // matches CUETools.AccurateRip/CDRepair.cs:1316-1324
            if let Some(positions) =
                crate::ctdb_rs::chien_search(gf, &sigma, errors_found, ctx.stridecount)
            {
                if positions.len() == errors_found {
                    best_offset_errors = errors_found;
                    best_offset = candidate_offset;
                }
            }
        }
    }

    // C#: return true only if bestOffsetErrors < npar / 2.
    // matches CUETools.AccurateRip/CDRepair.cs:1332-1348
    if best_offset_errors < npar / 2 {
        Some(RsVerifiedMatch {
            entry: entry.clone(),
            offset: best_offset,
            confidence: ctdb_entry_confidence(entry),
            npar,
            source,
            column0_errors: best_offset_errors,
        })
    } else {
        None
    }
}

/// Source-faithful replacement for the previous verify_disc_via_rs() fast path.
///
/// This intentionally computes CUETools maxNpar=16 parity once, then derives
/// npar=8 or npar=16 comparison rows from that maxNpar workspace exactly as
/// AccurateRipVerify.GetSyndrome() does.
///
/// matches CUETools.AccurateRip/AccurateRip.cs:2782-2848
/// matches CUETools.AccurateRip/CDRepair.cs:1252-1349
pub fn verify_disc_via_rs(
    audio: &[i16],
    entries: &[CtdbEntry],
    offset_window: i32,
) -> Option<RsVerifiedMatch> {
    let codec = crate::ctdb_rs::CtdbCodec::new();
    let gf = codec.galois();
    let ctx = cuetools_build_syndrome_context(audio)?;

    // C# AccurateRipVerify holds parity with maxNpar=16 and GetSyndrome narrows
    // only the output npar. Do not compute npar=8 parity for npar=8 entries.
    // matches CUETools.AccurateRip/AccurateRip.cs:2247-2252
    // matches CUETools.AccurateRip/AccurateRip.cs:2798-2802
    let parity16 = crate::ctdb_rs::syndrome::compute_parity_matrix_from_audio(
        gf,
        audio,
        CUETOOLS_MAX_NPAR,
    )
    .ok()?;

    let stride = crate::ctdb_rs::STRIDE as i32;
    let source_lo = 1 - stride / 2;
    let source_hi = stride / 2 - 1;
    let requested_lo = -offset_window.abs();
    let requested_hi = offset_window.abs();
    let offset_lo = source_lo.max(requested_lo);
    let offset_hi = source_hi.min(requested_hi);

    let mut best_match: Option<RsVerifiedMatch> = None;

    for entry in entries {
        let candidate = verify_entry_via_syndrome_fast_path(
            gf,
            &parity16,
            &ctx,
            entry,
            offset_lo,
            offset_hi,
        );

        if let Some(candidate) = candidate {
            let replace = match best_match.as_ref() {
                None => true,
                Some(current) => {
                    candidate.confidence > current.confidence
                        || (candidate.confidence == current.confidence
                            && candidate.column0_errors < current.column0_errors)
                }
            };
            if replace {
                best_match = Some(candidate);
            }
        }
    }

    best_match
}

#[cfg(test)]
mod cuetools_translation_fixtures {
    use super::*;

    #[test]
    fn parity2syndrome_single_row_fixture() {
        let gf = crate::ctdb_rs::Galois16::new();
        let parity_row = [0x1234, 0xabcd, 0x0000, 0xbeef];
        let got = cuetools_parity_row_to_syndrome_row(&gf, &parity_row, 4, 4).unwrap();
        assert_eq!(got, vec![0x0716, 0x3907, 0xcf58, 0xcf08]);
    }

    #[test]
    fn bytes2syndrome_layout_fixture() {
        let mut bytes = Vec::new();
        for word in [0x1111u16, 0x3333, 0x2222, 0x4444] {
            bytes.extend_from_slice(&word.to_le_bytes());
        }

        let got = cuetools_bytes_to_syndrome_matrix(&bytes, 2, 2).unwrap();
        assert_eq!(got, vec![vec![0x1111, 0x2222], vec![0x3333, 0x4444]]);
    }
}
