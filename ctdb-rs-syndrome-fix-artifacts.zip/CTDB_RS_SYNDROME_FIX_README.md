# CTDB Reed-Solomon syndrome fast-path fix

Date: 2026-05-03

This bundle contains a drop-in patch for Tonepoet's `src/tui/ctdb.rs` CTDB Reed-Solomon verification path.

## What changed

The previous v2 syndrome implementation treated CTDB's one-row value as the wrong object. CUETools.NET does this instead:

1. `CTDBResponseEntry` exposes both `parity` and `syndrome` XML attributes.
2. `DBEntry` loads `syndrome` directly with `Bytes2Syndrome(1, npar, bytes)`. If `syndrome` is absent, it converts legacy inline `parity` with `Parity2Syndrome(1, 1, 8, 8, bytes)`.
3. `CDRepairEncode.FindOffset` computes `ar.GetSyndrome(npar, 1, -offset)`, XORs that one row with the entry's row, then accepts exact zero or a BM/Chien-correctable syndrome.
4. The offset search window is `1 - stride/2 .. stride/2`, which is `-5879..+5879` stereo sample pairs for CTDB's normal `stride=11760` i16 words.

The replacement code mirrors that call chain:

- It decodes `syndrome` as little-endian u16 row data.
- It converts legacy inline `parity` to a syndrome row using the same one-row parity-to-syndrome transform.
- It computes the audio parity matrix once per unique NPAR (`8` or `16`) and caches it.
- For each candidate offset, it uses row `(-2 * offset) mod STRIDE`, converts that row to the CUETools one-row syndrome form, XORs with the entry row, and validates with Berlekamp-Massey plus Chien search.
- It sorts entries by descending confidence and returns the first verified hit.
- If the one-row fast path does not verify an entry and `hasparity` is present, it downloads the full parity blob and calls the existing exact `try_verify_with_word_offset` fallback.

## Apply instructions

1. Open `src/tui/ctdb.rs`.
2. Apply `/mnt/data/ctdb-rs-syndrome-fastpath.patch` manually or use it as a guided patch. It is intentionally written as a readable patch because the exact v2 file context may differ.
3. Ensure `CtdbEntry` contains these fields:

```rust
pub has_parity: Option<String>,
pub parity: Option<String>,
pub syndrome: Option<String>,
```

4. Ensure `parse_ctdb_response` extracts:

```rust
let parity = extract_attr(trimmed, "parity");
let syndrome = extract_attr(trimmed, "syndrome");
```

5. Replace the old v2 implementations of:

- `verify_disc_via_rs`
- `verify_disc_via_syndromes_blocking`
- `syndrome_row_from_entry`
- `parity_matrix_row_to_syndrome_row`

with the block in the patch.

6. Keep the existing high-level `verify_ctdb` / `verify_ctdb_single_image` flow: decode audio, assemble `[STRIDE leadin] + tracks + [STRIDE leadout]`, call `verify_disc_via_rs`, then use the matched entry's `track_crcs` for diagnostics. Track CRC mismatches under an RS-verified entry should display `VerifiedRs`, not `Mismatch`.

7. No changes are required in `src/ctdb_rs/mod.rs`.

## Compile checks

Run:

```bash
cargo fmt
cargo check
cargo test ctdb
```

If `base64::Engine` is unavailable, the project is using an older `base64` crate. Replace the decoder call in `decode_base64_u16_le_row` with:

```rust
let bytes = base64::decode(value.trim()).ok()?;
```

## Verification tests to run

1. The known Allman Brothers Japan SHM Disc 2 case should verify against the confidence-896 entry.
2. A byte-identical common pressing should return exact `column0_errors=Some(0)`.
3. A deliberately shifted rip at offsets `-5879`, `0`, `+5879` should locate the offset and reject `+/-5880`.
4. An entry with only inline `parity="..."` and no `syndrome` should still be accepted when valid.
5. A random or wrong-disc CTDB response should not pass BM alone; Chien validation must reject it.
6. A case that is correctable in column 0 but not in other columns should be treated as a known limitation unless a future full correctable verifier is added.
7. Multi-disc folders should continue using per-disc TOCs; never pool entries across discs.

## Important limitation

CUETools' full recovery path calls `VerifyParity`, which validates every stride column with BM/Chien/Forney and a CRC residual check after `FindOffset` reports errors and `hasparity` exists. Tonepoet's current public codec fallback, `try_verify_with_word_offset`, is exact-match only. This patch therefore matches CUETools' one-row fast path and preserves the requested exact full-parity fallback, but it does not add a full all-column correctable verifier to `ctdb_rs`.
